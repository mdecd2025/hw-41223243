from controller import Robot

try:
    # Webots 控制器設定
    robot = Robot()
    timestep = int(robot.getBasicTimeStep())
    distance_sensor = robot.getDistanceSensor('distance_sensor')
    distance_sensor.enable(timestep)

    # 這裡是你可能會遇到錯誤的程式碼
    while robot.step(timestep) != -1:
        value = distance_sensor.getValue()
        if value < 0:
            raise ValueError("感測器返回的值無效")

except Exception as e:
    print(f"錯誤: {e}")  # 捕獲所有錯誤並打印
